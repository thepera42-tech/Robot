"""
Local pump bridge server.

Serves both front-end pages and the pump control API from one process:
  http://localhost:5005/       -> kiosk.html      (the controller UI)
  http://localhost:5005/test   -> test_mode.html  (the TV test dashboard)

HOW IT TALKS TO THE ARDUINO (choose with PUMP_TRANSPORT, or `bash start.sh <mode>`):
  mock    a built-in simulated Arduino — no hardware needed (default on the TV)
  serial  a normal serial port via pyserial — laptops (Windows/Mac/Linux)
  termux  raw USB through Termux — Android TV / phone, no root needed
  auto    termux when running inside Termux, otherwise serial

Run it with start.sh (Linux/Mac/Termux) or start.bat (Windows).
Install once (laptop):  pip install -r requirements.txt
"""

import os
import sys
import time
import logging
import threading
import queue
from flask import Flask, request, jsonify, send_from_directory

try:                                   # only needed for the "serial" transport
    import serial
    from serial.tools import list_ports
except ImportError:                    # e.g. Termux — that's fine
    serial = None
    list_ports = None

from usb_transport import UsbError as TransportError, TermuxUsbSerial, get_termux_fd

# ---- CONFIGURE (or set these as environment variables) ----
TRANSPORT = os.environ.get("PUMP_TRANSPORT", "mock").lower()   # mock | serial | termux | auto
SERIAL_PORT = os.environ.get("PUMP_SERIAL_PORT", "auto")       # "auto", or e.g. "COM5" / "/dev/ttyACM0"
BAUD_RATE = 9600
PUMP_COUNT = 9  # 1-8 flavor pumps, 9 = primary sparkling water pump
HOST = os.environ.get("PUMP_HOST", "127.0.0.1")   # use 0.0.0.0 to open it from other devices
PORT = int(os.environ.get("PUMP_PORT", "5005"))
# -------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.join(BASE_DIR, "public")
LOG_DIR = os.path.join(BASE_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, "server.log")),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("pump_backend")

app = Flask(__name__)
from flask_cors import CORS
CORS(app)  # harmless to keep even now both pages are same-origin

arduino = None
arduino_lock = threading.Lock()
state_lock = threading.Lock()
command_lock = threading.Lock()   # only one command on the wire at a time
reply_queue = queue.Queue()       # OK / ERR lines, routed here by serial_reader

DONE_GRACE_SECONDS = 2.0  # if a timed FIRE's DONE never shows up, force idle after this

pump_state = {
    i: {"active": False, "speed": 0, "total_seconds": 0.0,
        "started_at": None, "fire_end": None}
    for i in range(1, PUMP_COUNT + 1)
}


# ---------------- serial handling ----------------

class MockArduino:
    """Stands in for a real Arduino running pump_controller.ino. Understands the
    same line protocol (FIRE/START/STOP/STOPALL), replies OK the same way, and
    fires DONE <id> after the requested duration — so everything above this
    (Flask routes, kiosk UI, test dashboard) behaves exactly like it will with
    real hardware, just without a serial port underneath."""

    def __init__(self):
        self._lines = queue.Queue()
        log.info("Simulated Arduino active — mimicking pump_controller.ino, no hardware required.")

    def write(self, data):
        # Mirrors handleLine() in pump_controller.ino line for line, including
        # its exact bad_pump / bad_format error replies, so a script that
        # passes against the mock behaves identically against real hardware.
        line = data.decode(errors="ignore").strip()
        parts = line.split()
        if not parts:
            return
        cmd = parts[0]

        if cmd == "STOPALL":
            self._lines.put(b"OK\n")
            return

        if cmd == "STOP":
            pump_id = self._int(parts[1]) if len(parts) >= 2 else None
            if pump_id is None or not (1 <= pump_id <= PUMP_COUNT):
                self._lines.put(b"ERR bad_pump\n")
                return
            self._lines.put(b"OK\n")
            return

        if cmd == "START":
            if len(parts) < 3:
                self._lines.put(b"ERR bad_format\n")
                return
            pump_id = self._int(parts[1])
            if pump_id is None or not (1 <= pump_id <= PUMP_COUNT):
                self._lines.put(b"ERR bad_pump\n")
                return
            self._lines.put(b"OK\n")
            return

        if cmd == "FIRE":
            if len(parts) < 4:
                self._lines.put(b"ERR bad_format\n")
                return
            pump_id = self._int(parts[1])
            ms = self._int(parts[2]) or 0
            if pump_id is None or not (1 <= pump_id <= PUMP_COUNT):
                self._lines.put(b"ERR bad_pump\n")
                return
            self._lines.put(b"OK\n")

            def finish():
                time.sleep(max(ms, 0) / 1000.0)
                self._lines.put(f"DONE {pump_id}\n".encode())

            threading.Thread(target=finish, daemon=True).start()
            return

        self._lines.put(b"ERR unknown_command\n")

    @staticmethod
    def _int(token):
        try:
            return int(token)
        except (TypeError, ValueError):
            return None

    def readline(self):
        try:
            return self._lines.get(timeout=1)
        except queue.Empty:
            return b""


def on_termux():
    return bool(os.environ.get("TERMUX_VERSION")) or "com.termux" in os.environ.get("PREFIX", "")


def resolved_transport():
    if TRANSPORT == "auto":
        return "termux" if on_termux() else "serial"
    return TRANSPORT


class SerialTransport:
    """pyserial, wrapped so every failure surfaces as TransportError."""

    def __init__(self, port_name):
        try:
            self._ser = serial.Serial(port_name, BAUD_RATE, timeout=1)
        except (serial.SerialException, OSError) as e:
            raise TransportError("could not open %s: %s" % (port_name, e))
        self.port = port_name
        time.sleep(2)  # Arduino resets when the serial port opens

    def write(self, data):
        try:
            self._ser.write(data)
        except (serial.SerialException, OSError) as e:
            raise TransportError(str(e))

    def readline(self):
        try:
            return self._ser.readline()
        except (serial.SerialException, OSError) as e:
            raise TransportError(str(e))

    def close(self):
        try:
            self._ser.close()
        except Exception:
            pass


ARDUINO_VIDS = {0x2341, 0x2A03, 0x1B4F, 0x239A, 0x1A86, 0x0403, 0x10C4}


def find_serial_port():
    if SERIAL_PORT.lower() != "auto":
        return SERIAL_PORT
    ports = list(list_ports.comports())
    for p in ports:
        text = ((p.description or "") + " " + (p.manufacturer or "")).lower()
        if p.vid in ARDUINO_VIDS or "arduino" in text or "ch340" in text:
            return p.device
    if len(ports) == 1:
        return ports[0].device
    if not ports:
        raise TransportError(
            "no serial ports found — is the Arduino plugged in? "
            "(Windows + clone boards may need the CH340 driver)")
    raise TransportError("several serial ports found and none look like an Arduino — "
                         "set PUMP_SERIAL_PORT to one of: " + ", ".join(p.device for p in ports))


_termux_cooldown = {"until": 0.0, "error": None}


def open_transport():
    """Returns (device, human-readable detail). Raises TransportError if unavailable."""
    kind = resolved_transport()

    if kind == "mock":
        return MockArduino(), "Simulated Arduino"

    if kind == "serial":
        if serial is None:
            raise TransportError("pyserial isn't installed — run: pip install pyserial")
        port = find_serial_port()
        dev = SerialTransport(port)
        return dev, "Serial port " + port

    if kind == "termux":
        fd = get_termux_fd()
        if fd is None:
            raise TransportError(
                "Android hasn't handed over the Arduino. Start with:  bash start.sh termux")
        if time.time() < _termux_cooldown["until"]:       # don't hammer a failing device
            raise _termux_cooldown["error"]
        try:
            dev = TermuxUsbSerial(fd, BAUD_RATE)
        except TransportError as e:
            _termux_cooldown.update(until=time.time() + 15, error=e)
            raise
        return dev, dev.describe()

    raise TransportError("unknown PUMP_TRANSPORT '%s' (use mock, serial, termux or auto)" % TRANSPORT)


transport_detail = ""


def get_serial():
    """Open the Arduino link once (whichever transport is configured) and start
    the background reader. Raises TransportError if it isn't reachable — callers
    catch that so one unplugged board doesn't crash the whole server."""
    global arduino, transport_detail
    with arduino_lock:
        if arduino is None:
            dev, transport_detail = open_transport()
            arduino = dev
            log.info("Arduino link up: %s", transport_detail)
            threading.Thread(target=serial_reader, args=(dev,), daemon=True).start()
    return arduino


def _finalize(pump_id):
    s = pump_state[pump_id]
    if s["started_at"] is not None:
        s["total_seconds"] += time.time() - s["started_at"]
    s["active"] = False
    s["started_at"] = None
    s["fire_end"] = None


def _expire_stale():
    """Safety net (call with state_lock held): a timed FIRE whose DONE never
    arrived gets forced idle, and only the time it should have run is counted."""
    now = time.time()
    for pump_id, s in pump_state.items():
        fe = s["fire_end"]
        if s["active"] and fe is not None and now > fe + DONE_GRACE_SECONDS:
            log.warning("Pump %s: no DONE received, forcing idle", pump_id)
            if s["started_at"] is not None:
                s["total_seconds"] += max(0.0, fe - s["started_at"])
            s["active"] = False
            s["started_at"] = None
            s["fire_end"] = None


def serial_reader(dev):
    global arduino
    while True:
        try:
            line = dev.readline().decode(errors="ignore").strip()
        except Exception as e:
            log.error("Arduino link lost: %s", e)
            break
        if not line:
            continue
        log.info("ARDUINO: %s", line)
        if line.startswith("DONE"):
            try:
                pump_id = int(line.split()[1])
            except (IndexError, ValueError):
                continue
            with state_lock:
                _finalize(pump_id)
        else:
            # OK / ERR ... = reply to the command send_command() is waiting on
            reply_queue.put(line)

    # Link died (unplugged / USB error): forget it so the next request retries.
    with arduino_lock:
        if arduino is dev:
            arduino = None
    try:
        dev.close()
    except Exception:
        pass


def live_status():
    _expire_stale()
    now = time.time()
    out = []
    for pump_id, s in pump_state.items():
        total = s["total_seconds"]
        if s["active"] and s["started_at"] is not None:
            total += now - s["started_at"]
        out.append({
            "pump": pump_id, "active": s["active"],
            "speed": s["speed"], "total_seconds": round(total, 1),
        })
    return out


def send_command(cmd):
    """Send one line to the Arduino and return its reply, logging both sides."""
    ser = get_serial()
    with command_lock:
        while not reply_queue.empty():      # drop any stale reply
            try:
                reply_queue.get_nowait()
            except queue.Empty:
                break
        ser.write((cmd + "\n").encode())
        try:
            reply = reply_queue.get(timeout=2.0)
        except queue.Empty:
            reply = ""
    log.info("SENT: %s  -> REPLY: %s", cmd, reply or "(no reply)")
    return reply


# ---------------- static pages ----------------

def serve_page(name):
    """Pages live in public/ — or right next to backend.py (both work)."""
    for folder in (PUBLIC_DIR, BASE_DIR):
        if os.path.isfile(os.path.join(folder, name)):
            return send_from_directory(folder, name)
    return "%s not found (looked in %s and %s)" % (name, PUBLIC_DIR, BASE_DIR), 404


@app.route("/")
def serve_controller():
    return serve_page("kiosk.html")


@app.route("/test")
def serve_test():
    return serve_page("test_mode.html")


# ---------------- API ----------------

@app.route("/fire", methods=["POST"])
def fire():
    data = request.get_json(force=True)
    pump, ms, speed = int(data["pump"]), int(data.get("ms", 500)), int(data.get("speed", 100))
    if pump not in pump_state:
        return jsonify({"error": "bad pump %s (use 1-%d)" % (pump, PUMP_COUNT)}), 400
    try:
        with state_lock:
            now = time.time()
            pump_state[pump].update(active=True, speed=speed, started_at=now,
                                    fire_end=now + ms / 1000.0)
        reply = send_command(f"FIRE {pump} {ms} {speed}")
        if reply.startswith("ERR") or not reply:
            with state_lock:
                _finalize(pump)
        return jsonify({"arduino_reply": reply})
    except TransportError as e:
        log.error("FIRE failed, pump=%s: %s", pump, e)
        return jsonify({"error": str(e)}), 503


@app.route("/start", methods=["POST"])
def start():
    data = request.get_json(force=True)
    pump, speed = int(data["pump"]), int(data.get("speed", 100))
    if pump not in pump_state:
        return jsonify({"error": "bad pump %s (use 1-%d)" % (pump, PUMP_COUNT)}), 400
    try:
        reply = send_command(f"START {pump} {speed}")
        with state_lock:
            pump_state[pump].update(active=True, speed=speed, started_at=time.time())
        return jsonify({"arduino_reply": reply})
    except TransportError as e:
        log.error("START failed, pump=%s: %s", pump, e)
        return jsonify({"error": str(e)}), 503


@app.route("/stop", methods=["POST"])
def stop():
    data = request.get_json(force=True)
    pump = int(data["pump"])
    if pump not in pump_state:
        return jsonify({"error": "bad pump %s (use 1-%d)" % (pump, PUMP_COUNT)}), 400
    try:
        reply = send_command(f"STOP {pump}")
        with state_lock:
            _finalize(pump)
        return jsonify({"arduino_reply": reply})
    except TransportError as e:
        log.error("STOP failed, pump=%s: %s", pump, e)
        return jsonify({"error": str(e)}), 503


@app.route("/stopall", methods=["POST"])
def stopall():
    try:
        reply = send_command("STOPALL")
        with state_lock:
            for pump_id in pump_state:
                _finalize(pump_id)
        return jsonify({"arduino_reply": reply})
    except TransportError as e:
        log.error("STOPALL failed: %s", e)
        return jsonify({"error": str(e)}), 503


@app.route("/selftest", methods=["POST"])
def selftest():
    data = request.get_json(force=True)
    pumps = data.get("pumps", [])
    results = []
    try:
        for p in pumps:
            if p.get("id") not in pump_state:
                results.append({"pump": p.get("id"), "reply": "ERR bad_pump"})
                continue
            with state_lock:
                now = time.time()
                pump_state[p["id"]].update(active=True, speed=p.get("speed", 100),
                                           started_at=now, fire_end=now + 0.4)
            reply = send_command(f"FIRE {p['id']} 400 {p.get('speed', 100)}")
            if reply.startswith("ERR") or not reply:
                with state_lock:
                    _finalize(p["id"])
            results.append({"pump": p["id"], "reply": reply})
            time.sleep(0.5)
        return jsonify({"results": results})
    except TransportError as e:
        log.error("Self-test failed: %s", e)
        return jsonify({"error": str(e), "results": results}), 503


@app.route("/status", methods=["GET"])
def status():
    try:
        get_serial()
    except TransportError as e:
        log.error("Status check: serial unavailable: %s", e)
        return jsonify({"error": str(e)}), 503
    with state_lock:
        return jsonify(live_status())


_last_hw_error = {"msg": None}


@app.route("/hardware", methods=["GET"])
def hardware():
    """Tells the frontend whether it's talking to a simulated Arduino or a real
    one, how it's connected, and whether it's actually reachable. Always 200."""
    kind = resolved_transport()
    if kind == "mock":
        return jsonify({"mock": True, "connected": False, "transport": "mock",
                        "detail": "Simulated Arduino"})
    try:
        get_serial()
        return jsonify({"mock": False, "connected": True, "transport": kind,
                        "detail": transport_detail})
    except TransportError as e:
        if _last_hw_error["msg"] != str(e):       # log each new reason once, not every poll
            log.warning("Arduino not available (%s): %s", kind, e)
            _last_hw_error["msg"] = str(e)
        return jsonify({"mock": False, "connected": False, "transport": kind, "error": str(e)})


if __name__ == "__main__":
    log.info("Starting pump backend on http://%s:%d  (transport: %s)", HOST, PORT, resolved_transport())
    app.run(host=HOST, port=PORT)
